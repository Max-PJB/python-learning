from wtforms.widgets.core import *

# Compatibility imports
from wtforms.widgets.core import html_params, Input, HTMLString
